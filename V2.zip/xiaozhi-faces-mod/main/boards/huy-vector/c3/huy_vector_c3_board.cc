#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/oled_display.h"
#include "application.h"
#include "board.h"
#include "button.h"
#include "config.h"

#include <esp_log.h>
#include <driver/i2c_master.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>

#define TAG "HuyVectorC3Board"

class HuyVectorC3Board : public WifiBoard {
private:
    Button ptt_button_;
    Button next_face_button_;
    Button mode_button_;
    i2c_master_bus_handle_t display_i2c_bus_ = nullptr;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    Display* display_ = nullptr;

    void InitializeDisplayI2c() {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = I2C_NUM_0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &display_i2c_bus_));
    }

    void InitializeSsd1306Display() {
        esp_lcd_panel_io_i2c_config_t io_config = {};
        io_config.dev_addr = 0x3C;
        io_config.scl_speed_hz = 400 * 1000;
        io_config.control_phase_bytes = 1;
        io_config.dc_bit_offset = 6;
        io_config.lcd_cmd_bits = 8;
        io_config.lcd_param_bits = 8;
        io_config.on_color_trans_done = nullptr;
        io_config.user_ctx = nullptr;
        io_config.flags.dc_low_on_data = 0;
        io_config.flags.disable_control_phase = 0;

        esp_err_t err = esp_lcd_new_panel_io_i2c(display_i2c_bus_, &io_config, &panel_io_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to create SSD1306 I2C panel IO: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = GPIO_NUM_NC;
        panel_config.bits_per_pixel = 1;

        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = static_cast<uint8_t>(DISPLAY_HEIGHT),
        };
        panel_config.vendor_config = &ssd1306_config;

        err = esp_lcd_new_panel_ssd1306(panel_io_, &panel_config, &panel_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to create SSD1306 panel: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_));
        err = esp_lcd_panel_init(panel_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to initialize SSD1306: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(panel_, true));
        display_ = new OledDisplay(
            panel_io_, panel_, DISPLAY_WIDTH, DISPLAY_HEIGHT,
            DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);

        ESP_LOGI(TAG, "SSD1306 initialized: SDA=%d SCL=%d addr=0x3C %dx%d",
            DISPLAY_SDA_PIN, DISPLAY_SCL_PIN, DISPLAY_WIDTH, DISPLAY_HEIGHT);
    }

    void InitializeTouchButtons() {
        // Dasai Mochi SuperMini TTP223 map: TALK=GPIO3, NEXT=GPIO6, MODE=GPIO7.
        // TTP223 outputs are active-HIGH, so the Button class is constructed
        // with active_high=true.
        next_face_button_.OnClick([]() {
            ESP_LOGI(TAG, "TTP223 NEXT -> CycleFace");
            auto* display = dynamic_cast<OledDisplay*>(Board::GetInstance().GetDisplay());
            if (display != nullptr) {
                display->CycleFace();
            }
        });

        mode_button_.OnClick([]() {
            ESP_LOGI(TAG, "TTP223 MODE -> ToggleInfoMode");
            auto* display = dynamic_cast<OledDisplay*>(Board::GetInstance().GetDisplay());
            if (display != nullptr) {
                display->ToggleInfoMode();
            }
        });
    }

    void InitializePttButton() {
        // Button() defaults to active-low and keeps the GPIO pull enabled.
        // Hardware: GPIO4 -> push button -> GND.
        ptt_button_.OnPressDown([]() {
            ESP_LOGI(TAG, "PTT pressed -> StartListening");
            Application::GetInstance().StartListening();
        });

        ptt_button_.OnPressUp([]() {
            ESP_LOGI(TAG, "PTT released -> StopListening");
            Application::GetInstance().StopListening();
        });
    }

public:
    HuyVectorC3Board() : ptt_button_(BOOT_BUTTON_GPIO, true), next_face_button_(NEXT_FACE_BUTTON_GPIO, true), mode_button_(MODE_BUTTON_GPIO, true) {
        InitializeDisplayI2c();
        InitializeSsd1306Display();
        InitializePttButton();
        InitializeTouchButtons();
        ESP_LOGI(TAG, "Huy Vector C3 initialized: TTP223 TALK=%d NEXT=%d MODE=%d", BOOT_BUTTON_GPIO, NEXT_FACE_BUTTON_GPIO, MODE_BUTTON_GPIO);
    }

    virtual AudioCodec* GetAudioCodec() override {
        static NoAudioCodecDuplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE,
            AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_BCLK,
            AUDIO_I2S_GPIO_WS,
            AUDIO_I2S_GPIO_DOUT,
            AUDIO_I2S_GPIO_DIN);
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return display_;
    }
};

DECLARE_BOARD(HuyVectorC3Board);
