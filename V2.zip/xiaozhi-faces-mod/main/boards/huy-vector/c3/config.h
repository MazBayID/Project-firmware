#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// Huy Vector ESP32-C3 + INMP441 + MAX98357A + SSD1306
// Audio is handled by Xiaozhi's NoAudioCodecDuplex (raw I2S).
#define AUDIO_INPUT_SAMPLE_RATE  24000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// Shared I2S bus: INMP441 microphone + MAX98357A amplifier
#define AUDIO_I2S_GPIO_WS    GPIO_NUM_2
#define AUDIO_I2S_GPIO_BCLK  GPIO_NUM_1
#define AUDIO_I2S_GPIO_DIN   GPIO_NUM_8   // INMP441 SD
#define AUDIO_I2S_GPIO_DOUT  GPIO_NUM_5   // MAX98357A DIN (Dasai Mochi pin map)

// Physical push-to-talk button: GPIO4 -> push button -> GND.
// Button class uses active-low GPIO input with internal pull-up.
#define BOOT_BUTTON_GPIO GPIO_NUM_3   // TTP223 TALK, active-HIGH
#define NEXT_FACE_BUTTON_GPIO GPIO_NUM_6 // TTP223 NEXT, active-HIGH
#define MODE_BUTTON_GPIO GPIO_NUM_7   // TTP223 MODE, active-HIGH

#define BUILTIN_LED_GPIO GPIO_NUM_NC

#define DISPLAY_SDA_PIN GPIO_NUM_21
#define DISPLAY_SCL_PIN GPIO_NUM_20
#define DISPLAY_WIDTH   128
#define DISPLAY_HEIGHT  64
#define DISPLAY_MIRROR_X false
#define DISPLAY_MIRROR_Y false

#endif // _BOARD_CONFIG_H_
