# Huy Vector ESP32-C3 Super Mini — Dasai Mochi Face Mod

Custom XiaoZhi board configuration for:

- ESP32-C3 Super Mini
- INMP441 I2S microphone
- MAX98357A I2S amplifier
- SSD1306 128x64 I2C OLED
- 3x TTP223 touch sensors

## Wiring

### INMP441
- VDD -> 3.3V
- GND -> GND
- SCK -> GPIO1
- WS -> GPIO2
- SD -> GPIO8
- L/R -> GND

### MAX98357A
- VCC -> 5V
- GND -> GND
- DIN -> GPIO5
- BCLK -> GPIO1
- LRC/WS -> GPIO2

### OLED SSD1306
- SDA -> GPIO21
- SCL -> GPIO20
- I2C address -> 0x3C

### TTP223
- TALK SIG -> GPIO3
- NEXT SIG -> GPIO6
- MODE SIG -> GPIO7
- VCC -> 3.3V
- GND -> GND

TTP223 inputs are active-HIGH.

## Touch controls

- TALK: touch and hold to listen; release to stop listening.
- NEXT: cycle the face expression.
- MODE: show time/date/Wi-Fi signal information for 5 seconds, then return to the face.

## Radio configuration

- Bluetooth disabled.
- Wi-Fi provisioning uses hotspot mode, not BluFi.
- Wi-Fi maximum TX power is configured to 10 dBm.
- PTT/touch listening is used instead of wake word.
