XERO-inspired OLED face v0.4

This version keeps the existing Huy Vector C3 hardware mapping, audio, PTT, Wi-Fi,
MQTT/server and signal bar. The OLED face is implemented in oled_display.cc using
LVGL primitives. Default firmware UI language is forced to English (en-US).

Recommended build command:
python scripts/build.py huy-vector/c3 --language en-US
