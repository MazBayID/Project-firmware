# XiaoZhi Huy Vector C3 + Dasai Mochi Face Mod

This source is based on the working Huy Vector ESP32-C3 XiaoZhi firmware.

## First-stage goal

Keep the proven XiaoZhi audio/network/application stack and replace only the display/button layer with the Dasai Mochi-style face behavior and SuperMini TTP223 pin map.

The Arduino Dasai Mochi `audio_io.cpp` is intentionally **not** copied into this build. The previous Dasai Mochi source was known to crash during Push-to-Talk; this mod keeps XiaoZhi's existing `NoAudioCodecDuplex` I2S/audio path.

## Pin map

- INMP441 SCK -> GPIO1
- INMP441 WS -> GPIO2
- INMP441 SD -> GPIO8
- MAX98357A BCLK -> GPIO1
- MAX98357A LRC -> GPIO2
- MAX98357A DIN -> GPIO5
- OLED SDA -> GPIO21
- OLED SCL -> GPIO20
- TTP223 TALK -> GPIO3 (active HIGH)
- TTP223 NEXT -> GPIO6 (active HIGH)
- TTP223 MODE -> GPIO7 (active HIGH)

## Touch behavior

- TALK: touch and hold to listen; release to stop listening.
- NEXT: cycle through the face expressions.
- MODE: open the time/date/Wi-Fi signal screen for 5 seconds; another touch restarts the timer.

## What was deliberately preserved

- XiaoZhi networking and MQTT/protocol stack
- XiaoZhi audio capture/playback engine
- Huy Vector SSD1306 hardware initialization
- Bluetooth disabled
- Hotspot Wi-Fi provisioning
- Wi-Fi TX power limit
- English language configuration

The next planned stage is the separate Driver Assistant integration. It is intentionally not included in this stage.
