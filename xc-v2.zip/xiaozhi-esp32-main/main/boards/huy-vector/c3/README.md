# Huy Vector / ESP32-C3 Super Mini — XiaoZhi + Faces + TTP223 + Chronos

This board target preserves the working XiaoZhi Huy Vector audio/network core and adds:

- SSD1306 128x64 OLED on GPIO21/20
- XERO/Mochi-inspired monochrome face UI
- TTP223 touch controls
- Native ESP-IDF NimBLE Chronos bridge for phone notifications and navigation
- Wi-Fi TX power limited to 10 dBm

## Wiring

### INMP441
- VDD -> 3.3V
- GND -> GND
- SCK -> GPIO1
- WS -> GPIO2
- SD -> GPIO8
- L/R -> GND

### MAX98357A
- VIN -> 5V
- GND -> GND
- DIN -> GPIO5
- BCLK -> GPIO1
- LRC/WS -> GPIO2

### SSD1306 128x64
- SDA -> GPIO21
- SCL -> GPIO20
- Address -> 0x3C

### TTP223
- TALK OUT -> GPIO3
- NEXT OUT -> GPIO6
- MODE OUT -> GPIO7
- VCC -> 3.3V
- GND -> GND

TTP223 is configured active-HIGH.

## Touch behavior

- TALK: touch/hold = StartListening; release = StopListening
- NEXT: cycle face expression
- MODE: show clock + Wi-Fi signal for 5 seconds, then return to face

## Chronos

The Chronos protocol is implemented directly with ESP-IDF NimBLE, not Arduino/NimBLE-Arduino. The bridge uses the Chronos custom BLE service/characteristics and handles:

- phone notification packets
- Chronos time synchronization
- Google Maps navigation state/text
- navigation icon packets are accepted for protocol compatibility (text rendering is used in this first native bridge to keep RAM/flash use low)

Bluetooth is enabled only for this Chronos BLE peripheral. BluFi remains disabled because Wi-Fi provisioning uses hotspot mode.
